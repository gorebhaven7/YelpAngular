import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, NgForm,  ValidationErrors, NgModel } from '@angular/forms';
import { AppServiceService } from './app-service.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  filteredOptions: any[] = [];
  key :string = '';
  loc:string = '';
  dist:string = '';
  cat:string = '';
  lat: string = '';
  long: string = '';
  ydata:any = false;
  checkydata:boolean = false;
  cardData:any = false;
  cate:any="";
  images:any = [];

  selectedCategory: string = 'all';

  selectedCategoryChangeHandler (event: any) {
    this.selectedCategory = event.target.value;
    // console.log(this.selectedCategory);
  }



  constructor(private service: AppServiceService) { 
   }

  ngOnInit() {

    // console.log('ngOnInit');
    }

  onInputChange(){
    let k = document.getElementById('typeKeyword') as HTMLInputElement;
    // console.log(k.value);
    if(k.value.length >= 1){
      // console.log(typeof(k.value));
      this.service.getAutoComplete(k.value).subscribe((data:any) => {
        // console.log(data);
        this.filteredOptions = data.terms.map((item:any) => item.text);
        // console.log(this.filteredOptions); 
        for(let i of data.categories){
          this.filteredOptions.push(i.title);
        }
      })
    }
  }

  fetchYelpData(){
    // console.log('fetching data');
    // console.log(this.key, this.lat, this.long, this.dist, this.selectedCategory);
    this.service.secondTableData(this.key, this.lat, this.long, this.dist, this.selectedCategory).subscribe((data:any) => {
      this.ydata = data.businesses;
      console.log(this.ydata);
      if(this.ydata.length > 0){
        this.checkydata = true;
      }
      else{
        this.checkydata = false;
      }
      console.log(this.checkydata);
    });
  }

  submit(bussForm:any){ 
    // console.log('Submitted');
    
    this.key = bussForm.value.key;
    if(bussForm.value.distance == ''){
      this.dist = "10";
      bussForm.value.distance = 10;
    }
    else{
      this.dist = bussForm.value.distance;
    }
    if(bussForm.value.check){
      this.service.getIP().subscribe((data:any) => {
        // console.log(data);
        this.lat = data.loc.split(',')[0];
        this.long = data.loc.split(',')[1];
        console.log(this.lat);
        console.log(this.long);
        this.fetchYelpData();
        })
    }
    else{
      this.loc = bussForm.value.location;
      // console.log(this.loc);
      this.service.getLocation(this.loc).subscribe((data:any) => {
        // console.log(data);
        this.lat = data.results[0].geometry.location.lat;
        this.long = data.results[0].geometry.location.lng;
        console.log(this.lat);
        console.log(this.long);
        this.fetchYelpData();
      });
      
  }
  // console.log(bussForm.value);
  }

  get_card_data(id:any){
    console.log(id);

    this.service.getCardData(id).subscribe((data:any) => {
      this.cardData = data;
      this.cate = data.categories.map((a:any)=>a.title).join('| ');
      this.images = data.photos;
      console.log(data);
      console.log(this.cate);
      console.log(this.images);
    
  });
}

}
